jQuery(function () {
    AOS.init({
        duration: 2000,
        once: false,
        offset: 120,
        easing: "ease-in-out",
        mirror: false,
    });
});

// Header sticky start
jQuery(document).ready(function (e) {
    let lastScroll = 0;
    const header = document.querySelector(".header");
    window.addEventListener("scroll", () => {
        let currentScroll = window.pageYOffset;
        // scroll down
        if (currentScroll > lastScroll) {
            header.classList.add("hide");
            header.classList.remove("active-header");
        }
        // scroll up
        else {
            header.classList.remove("hide");
            // add bg color class when scrolling up
            if (currentScroll > 50) {
                header.classList.add("active-header");
            } else {
                header.classList.remove("active-header");
            }
        }
        lastScroll = currentScroll;
    });
});

/* DropDown Button Open */
jQuery(document).ready(function (e) {
    function t(t) {
        e(t).bind("click", function (t) {
            t.preventDefault();
            e(this).parent().fadeOut()
        })
    }
    e(".dropdown-btn .btn-fill").click(function () {
        var t = e(this).parents(".button-dropdown").children(".dropdown-btn ul").is(":hidden");
        e(".dropdown-btn ul").hide();
        e(".dropdown-btn .btn-fill").removeClass("active");
        if (t) {
            e(this).parents(".button-dropdown").children(".dropdown-btn ul").toggle().parents(".button-dropdown").children(".dropdown-btn .btn-fill").addClass("active")
        }
    });
    e(document).bind("click", function (t) {
        var n = e(t.target);
        if (!n.parents().hasClass("button-dropdown")) e(".dropdown-btn ul").hide();
    });
    e(document).bind("click", function (t) {
        var n = e(t.target);
        if (!n.parents().hasClass("button-dropdown")) e(".dropdown-btn .btn-fill").removeClass("active");
    })
});
/* DropDown Button Close */

/* Form Section Style Open */
jQuery('input,textarea,select').val("");
jQuery('.form-control, input, select, textarea').focusout(function () {
    var text_val = $(this).val();
    if (text_val === "") {
        console.log("empty!");
        $(this).removeClass('has-value');
    } else {
        $(this).addClass('has-value');
    }
});
/* Form Section Style Close */

/* Footer Dropdown Open */
const accordions = document.querySelectorAll(".footer-accordion-menu");
accordions.forEach(item => {
    const button = item.querySelector(".accordion-buuton-footer");
    button.addEventListener("click", () => {
        // Only Mobile
        if (window.innerWidth <= 991) {
            item.classList.toggle("active");
        }
    });
});
/* Footer Dropdown Close */

// Logo Scroller Start //
jQuery(document).ready(function () {
    jQuery('.logo-scroller').owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        dots: false,
        mouseDrag: true,
        touchDrag: true,
        freeDrag: false,
        autoplay: false,
        autoplaySpeed: 2000,
        slideTransition: 'linear',
        responsive: {
            0: {
                items: 2,
                autoplay: true,
            },
            480: {
                items: 2.5,
                autoplay: true,
            },
            600: {
                items: 3,
                autoplay: true,
            },
            1000: {
                items: 8
            }
        }
    });

    function initBusinessChooseCarousel() {
        const $businessCards = jQuery('.servinn-achieved-cards-list');
        const shouldInit = jQuery(window).width() < 992;
        const isInitialized = $businessCards.hasClass('owl-loaded');
        if (shouldInit && !isInitialized) {
            $businessCards.addClass('owl-carousel').owlCarousel({
                margin: 20,
                nav: false,
                dots: false,
                mouseDrag: true,
                touchDrag: true,
                loop: true,
                smartSpeed: 2000,
                autoplayTimeout: 1500,
                autoplay: true,
                autoplaySpeed: 2000,
                responsive: {
                    0: { items: 1 },
                    640: { items: 1 },
                    768: { items: 2 }
                }
            });
        } else if (!shouldInit && isInitialized) {
            $businessCards.trigger('destroy.owl.carousel');
            $businessCards.removeClass('owl-carousel owl-loaded owl-hidden');
            $businessCards.find('.owl-stage-outer, .owl-stage, .owl-item').children().unwrap();
        }
    }
    initBusinessChooseCarousel();
    jQuery(window).on('resize', function () {
        initBusinessChooseCarousel();
    });
});
// Logo Scroller End //

const counters = document.querySelectorAll(".counter-number");
function startCounter(counter) {
    const target = parseInt(counter.dataset.count);
    const duration = parseInt(counter.dataset.duration) || 2000;
    const sign = counter.dataset.sign || "+";
    let start = 0;
    let startTime = null;
    function animateCounter(timestamp) {
        if (!startTime) {
            startTime = timestamp;
        }
        const progress = timestamp - startTime;
        const value = Math.min(
            Math.floor((progress / duration) * target),
            target
        );
        counter.innerText = value + sign;
        if (progress < duration) {
            requestAnimationFrame(animateCounter);
        } else {
            counter.innerText = target + sign;
        }
    }
    requestAnimationFrame(animateCounter);
}
/* =========================
   INTERSECTION OBSERVER
========================= */
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            startCounter(entry.target);
            observer.unobserve(entry.target);
        }
    });
}, {
    threshold: 0.5
});
counters.forEach(counter => {
    observer.observe(counter);
});
// COUNTER SECTION END //

// Solutions Designed Start //
jQuery(document).ready(function () {
    function initServiceTabs() {
        let serviceTabs = jQuery(".services-section .tab-title");
        let servicePanels = jQuery(".services-section .tab-content");
        if (!serviceTabs.length || !servicePanels.length) {
            return;
        }
        jQuery(".services-section .tab-item").removeClass("active");
        servicePanels.removeClass("active");
        let firstTab = jQuery(".services-section .tab-item:first");
        firstTab.addClass("active");
        let firstPanel = jQuery("#" + firstTab.data("tab"));
        firstPanel.addClass("active");

        serviceTabs.on("click", function (e) {
            e.preventDefault();
            let tabItem = jQuery(this).closest(".tab-item");
            let targetTab = tabItem.data("tab");
            if (!targetTab) {
                return;
            }
            let currentTab = jQuery(".services-section .tab-item.active");
            let currentPanel = servicePanels.filter(".active");
            let targetPanel = jQuery("#" + targetTab);
            let currentAccordion = currentTab.find(".accordion-content");
            let targetAccordion = tabItem.find(".accordion-content");
            if (currentPanel.length && currentPanel[0] !== targetPanel[0]) {
                currentPanel.removeClass("active");
                targetPanel.addClass("active");
                targetPanel.find('.tech-slider').trigger('refresh.owl.carousel');
            }
            if (currentAccordion.length && currentAccordion[0] !== targetAccordion[0]) {
                currentAccordion.hide();
                targetAccordion.show();
            }
            jQuery(".services-section .tab-item").removeClass("active");
            tabItem.addClass("active");
        });
    }
    initServiceTabs();
    jQuery('.case-study-slider').owlCarousel({
        loop: true,
        margin: 30,
        nav: true,
        dots: false,
        items: 1,
        smartSpeed: 800,
        navText: [
            '<img src="assets/icons/NewArrowLeftSmall.svg" alt="Left">',
            '<img src="assets/icons/NewArrowRightSmall.svg" alt="Right">'
        ]
    });
});
// Solutions Designed End //

// Tech Slider Start //
jQuery(document).ready(function () {
    jQuery('.tech-slider').each(function () {
        jQuery(this).owlCarousel({
            margin: 15,
            nav: false,
            dots: false,
            loop: true,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: false,
            smartSpeed: 2000,
            navText: [
                '<img src="assets/icons/NewArrowLeftSmall.svg" alt="Left">',
                '<img src="assets/icons/NewArrowRightSmall.svg" alt="Right">'
            ],
            responsive: {
                0: {
                    items: 2
                },
                620: {
                    items: 3
                },
                768: {
                    items: 4
                },
                1208: {
                    items: 7
                },
                1600: {
                    items: 8
                }
            }
        });
    });
});
// Tech Slider End //

/* matrix growth network and testimonial section script start */
jQuery(document).ready(function () {
    /* ---------- Intersection Observer: Growth Framework Section ---------- */
    const $growthSection = $('#growth-framework');
    if ($growthSection.length) {
        const observer = new IntersectionObserver(
            function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        $(entry.target).addClass('in-view');
                        // Animate progress line to each dot
                        animateProgressLine();
                    } else {
                        $(entry.target).removeClass('in-view');
                        // Reset progress line
                        const $timeline = $('.growth-timeline');
                        if ($timeline.length) {
                            $timeline[0].style.setProperty('--progress-width', '0px');
                        }
                    }
                });
            },
            {
                threshold: 0.2
            }
        );
        observer.observe($growthSection[0]);
    }
    /* ---------- Progress Line Animation ---------- */
    function animateProgressLine() {
        const $timeline = $('.growth-timeline');
        const $items = $('.growth-timeline-item');

        if (!$timeline.length || !$items.length) return;
        const isMobile = window.innerWidth <= 991;
        var delays = [0, 1000, 2000, 3000, 4000, 5000];
        $items.each(function (index) {
            var delay = delays[index] || 0;
            setTimeout(() => {
                if (isMobile) {
                    const $dot = $(this).find('.timeline-dot');
                    const dotTop =
                        $dot.offset().top -
                        $timeline.offset().top +
                        ($dot.outerHeight() / 2);
                    $timeline[0].style.setProperty(
                        '--progress-height',
                        dotTop + 'px'
                    );
                } else {
                    let widthPx;
                    if (index === $items.length - 1) {
                        widthPx = $(window).width();
                    } else {
                        const $dot = $(this).find('.timeline-dot');
                        widthPx =
                            $dot.offset().left +
                            ($dot.outerWidth() / 2);
                    }
                    $timeline[0].style.setProperty(
                        '--progress-width',
                        widthPx + 'px'
                    );
                }
            }, delay);
        });
    }
    /* ---------- Testimonial Slider (Owl Carousel) ---------- */
    if ($('.testimonial-carousel').length) {
        $('.testimonial-carousel').owlCarousel({
            loop: true,
            margin: 30,
            nav: true,
            dots: false,
            items: 1,
            navText: [
                '<img src="assets/icons/NewArrowLeftSmall.svg" alt="Left">',
                '<img src="assets/icons/NewArrowRightSmall.svg" alt="Right">'
            ],
            autoplay: false,
            smartSpeed: 800
        });
    }
});
/* matrix growth network and testimonial section script ended */

/* faq ui start */
(function () {
    const container = document.querySelector('.faq-accordion');
    if (!container) return;
    const items = Array.from(container.querySelectorAll('.faq-item'));

    // initialize closed
    items.forEach(item => {
        const q = item.querySelector('.faq-question');
        const p = item.querySelector('.faq-answer');
        if (q) { q.classList.remove('active'); q.setAttribute('aria-expanded', 'false'); }
        if (p) { p.style.maxHeight = null; p.setAttribute('aria-hidden', 'true'); }
        const toggle = q && q.querySelector('.faq-toggle'); if (toggle) toggle.textContent = '▼';
    });
    // delegate clicks
    container.addEventListener('click', function (e) {
        const btn = e.target.closest('.faq-question');
        if (!btn || !container.contains(btn)) return;
        e.preventDefault();
        const item = btn.closest('.faq-item');
        const panel = item.querySelector('.faq-answer');
        const isActive = btn.classList.contains('active');
        // close all
        items.forEach(it => {
            const b = it.querySelector('.faq-question');
            const p = it.querySelector('.faq-answer');
            const t = b && b.querySelector('.faq-toggle');
            if (b) { b.classList.remove('active'); b.setAttribute('aria-expanded', 'false'); }
            if (p) { p.style.maxHeight = null; p.setAttribute('aria-hidden', 'true'); }
            if (t) t.textContent = '▼';
        });
        // open clicked if it was closed
        if (!isActive) {
            btn.classList.add('active');
            if (panel) { panel.style.maxHeight = panel.scrollHeight + 'px'; panel.setAttribute('aria-hidden', 'false'); }
            const toggle = btn.querySelector('.faq-toggle'); if (toggle) toggle.textContent = '▲';
            btn.setAttribute('aria-expanded', 'true');
        }
    });
})();
/* faq ui ended */

/* Aos Open */
$(window).on('load', function () {
    setTimeout(function () {
        AOS.refreshHard();
    }, 500);
});
/* Aos Close */

/* Case Studdy Listing Dropdown Open */
jQuery(document).ready(function ($) {
    /* OPEN DROPDOWN */
    $(document).on("click", ".custom-select-box", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var wrapper = $(this).closest(".custom-select-wrapper");
        // Close all other dropdowns
        $(".custom-select-wrapper").not(wrapper).removeClass("active");
        // Toggle current dropdown
        wrapper.toggleClass("active");
    });
    /* SELECT OPTION */
    $(document).on("click", ".custom-options li", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var selectedText = $(this).text();
        var wrapper = $(this).closest(".custom-select-wrapper");
        // Update selected text
        wrapper.find(".selected-text").text(selectedText);
        // Close dropdown
        wrapper.removeClass("active");
    });
    /* CLOSE DROPDOWN WHEN CLICKING OUTSIDE */
    $(document).on("click", function (e) {
        var $target = $(e.target);
        if (!$target.closest(".custom-select-wrapper").length) {
            $(".custom-select-wrapper").removeClass("active");
        }
    });
});
/* Case Studdy Listing Dropdown Close */

/* case study 2 script start */
jQuery(document).ready(function () {
    if ($('.case-study-2-testimonial-carousel').length) {
        $('.case-study-2-testimonial-carousel').owlCarousel({
            loop: false,
            margin: 30,
            nav: false,
            dots: false,
            items: 1,
            navText: [
                '<img src="assets/icons/NewArrowLeftSmall.svg" alt="Left">',
                '<img src="assets/icons/NewArrowRightSmall.svg" alt="Right">'
            ],
            autoplay: false,
            smartSpeed: 800,

            responsive: {
                0: {
                    mouseDrag: false,
                    touchDrag: false,
                    pullDrag: false
                },
                1025: {
                    mouseDrag: false,
                    touchDrag: false,
                    pullDrag: false
                }
            }
        });
    }

});
function animateVerticalTimeline() {
    const $timeline = $('.growth-timeline-vertical');
    const $items = $('.growth-timeline-vertical-item');
    if (!$timeline.length) return;
    const delays = [0, 1000, 2000, 3000, 4000, 5000];
    $items.each(function (index) {
        setTimeout(() => {
            const $dot = $(this).find('.timeline-dot');
            const progressHeight =
                $dot.offset().top -
                $timeline.offset().top +
                ($dot.outerHeight() / 2);
            $timeline[0].style.setProperty(
                '--progress-height',
                progressHeight + 'px'
            );
            $(this).addClass('active');

        }, delays[index] || 0);
    });
}
const verticalTimeline = document.querySelector('.growth-timeline-vertical');
if (verticalTimeline) {
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateVerticalTimeline();
            }
        });
    }, {
        threshold: 0.2
    });
    observer.observe(verticalTimeline);
}
/* case study 2 script ended */

/* service page script start */
jQuery(document).ready(function () {
    // service main page tab
    jQuery('.service-tech-mobile-silder').each(function () {
        jQuery(this).owlCarousel({
            loop: false,
            margin: 15,
            nav: false,
            dots: false,
            smartSpeed: 600,
            navText: [
                '<img src="assets/icons/NewArrowLeftSmall.svg" alt="Left">',
                '<img src="assets/icons/NewArrowRightSmall.svg" alt="Right">'
            ],
            responsive: {
                0: {
                    items: 3
                },
                620: {
                    items: 4
                },
                768: {
                    items: 4
                },
                1208: {
                    items: 5
                },
                1600: {
                    items: 8
                }
            }
        });
    });

    // AI/ML service page tab
    jQuery('.aiml-service-mobile-slider').each(function () {
        jQuery(this).owlCarousel({
            loop: false,
            margin: 15,
            nav: false,
            dots: false,
            smartSpeed: 600,
            navText: [
                '<img src="assets/icons/arrow-left-carosel.svg" alt="Left">',
                '<img src="assets/icons/arrow-right-carosel.svg" alt="Right">'
            ],
            responsive: {
                0: {
                    items: 2
                },
                620: {
                    items: 3
                },
                768: {
                    items: 4
                },
                1208: {
                    items: 5
                },
                1600: {
                    items: 8
                }
            }
        });
    });

});
/* service page script ended */

/* Why Businesses Choose Accordion JavaScript */
jQuery(document).ready(function ($) {
    function openRow($row) {
        // Remove active class from other rows and slide them up
        $('.srvc-sctn-table-row').not($row).each(function () {
            closeRow($(this));
        });
        if (!$row.hasClass('active')) {
            $row.addClass('active');

            var $cell2 = $row.find('.srvc-sctn-table-cell:nth-child(3)'); // Our Solution
            var $cell1 = $row.find('.srvc-sctn-table-cell:nth-child(2)'); // Challenge

            // Slide down Cell 2 immediately
            $cell2.stop(true, true).slideDown({
                duration: 350,
                easing: 'swing'
            });
            // Slide down Cell 1 with a delay
            setTimeout(function () {
                if ($row.hasClass('active')) {
                    $cell1.stop(true, true).slideDown({
                        duration: 350,
                        easing: 'swing'
                    });
                }
            }, 150);
        }
    }

    function closeRow($row) {
        if ($row.hasClass('active')) {
            $row.removeClass('active');
            var $cell2 = $row.find('.srvc-sctn-table-cell:nth-child(3)');
            var $cell1 = $row.find('.srvc-sctn-table-cell:nth-child(2)');
            // Slide up Cell 1 immediately
            $cell1.stop(true, true).slideUp({
                duration: 350,
                easing: 'swing'
            });

            // Slide up Cell 2 with a delay
            setTimeout(function () {
                if (!$row.hasClass('active')) {
                    $cell2.stop(true, true).slideUp({
                        duration: 350,
                        easing: 'swing'
                    });
                }
            }, 150);
        }
    }

    $('.srvc-sctn-table').on('click', '.srvc-table-btn', function (e) {
        if (window.innerWidth > 767) return;
        e.preventDefault();
        e.stopPropagation();
        var $row = $(this).closest('.srvc-sctn-table-row');
        if ($row.hasClass('active')) {
            closeRow($row);
        } else {
            openRow($row);
        }
    });

    $('.srvc-sctn-table').on('click', '.srvc-sctn-table-row', function (e) {
        if (window.innerWidth > 767) return;

        var $row = $(this);
        if ($row.hasClass('active')) {
            if ($(e.target).closest('.srvc-table-btn').length) {
                return;
            }
            e.preventDefault();
            closeRow($row);
        }
    });
});
/* Why Businesses Choose Accordion JavaScript ended */


// Career area start
jQuery(window).on('resize load', function ($) {
    if (jQuery(window).width() < 992) {
        jQuery('.career-left').css({
            position: 'static'
        });
    } else {
        jQuery('.career-left').css({
            position: 'sticky',
            top: '120px'
        });
    }
});

jQuery(function () {
    const $careerRight = $('.career-right');
    const $progressFill = $('.progress-fill-vertical');
    if (!$careerRight.length || !$progressFill.length) return;
    const updateProgress = function () {
        const sectionTop = $careerRight.offset().top;
        const sectionHeight = $careerRight.outerHeight();
        const viewportHeight = $(window).height();
        const scrollY = $(window).scrollTop();
        const start = sectionTop - viewportHeight;
        const end = sectionTop + sectionHeight;
        const progress = (scrollY - start) / (end - start);
        const percent = Math.min(1, Math.max(0, progress)) * 100;
        $progressFill.css('height', percent + '%');
    };

    $(window).on('scroll resize', updateProgress);
    updateProgress();
});
// Career area end

// Awards Scroller Start //
jQuery(document).ready(function () {
    jQuery('.awardsScroller').owlCarousel({
        loop: true,
        margin: 15,
        items: 12,
        nav: false,
        dots: false,
        mouseDrag: true,
        touchDrag: true,
        freeDrag: false,
        autoplay: true,
        autoplaySpeed: 2000,
        slideTransition: 'linear',
        responsive: {
            0: {
                items: 4,
                autoplay: true,
            },
            480: {
                items: 6,
                autoplay: true,
            },
            1000: {
                items: 10,
                autoplay: true,
            },
            1600: {
                items: 11,
                autoplay: true,
            },
            1800: {
                items: 12,
                autoplay: true,
            },
            2000: {
                items: 14,
                autoplay: true,
            }
        }
    });
});
// Awards Scroller End //

// File upload
jQuery(document).ready(function () {
    // Handle file input change
    const fileInput = document.getElementById('cv-upload');
    const fileNameSpan = document.getElementById('file-name');

    if (fileInput && fileNameSpan) {
        fileInput.addEventListener('change', function () {
            if (this.files && this.files.length > 0) {
                fileNameSpan.textContent = this.files[0].name;
            } else {
                fileNameSpan.textContent = 'Choose file & Upload CV*';
            }
        });

        // Also handle click on label to ensure file dialog opens
        const uploadBox = document.querySelector('.upload-box');
        if (uploadBox) {
            uploadBox.addEventListener('click', function (e) {
                if (e.target !== fileInput) {
                    fileInput.click();
                }
            });
        }
    }
});

// Team Page Script Start

jQuery(document).ready(function ($) {
    $('.team-member').hover(
        function () {
            // Mouse Enter
            if ($(window).width() > 991) {
                $(this).addClass('active');
            }
        },
        function () {
            // Mouse Leave
            if ($(window).width() > 991) {
                $(this).removeClass('active');
            }
        }
    );
    // Mobile Click
    $('.team-member').click(function () {
        if ($(window).width() <= 991) {
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
            } else {
                $('.team-member').removeClass('active');
                $(this).addClass('active');
            }
        }
    });
});

jQuery('.culture-slider').owlCarousel({
    items: 1,
    loop: true,
    nav: true,
    dots: false,
    autoplay: true,
    autoplayTimeout: 5000,
    smartSpeed: 800,
    navText: [
        '<i class="fa-solid fa-angle-left"></i>',
        '<i class="fa-solid fa-angle-right"></i>'
    ]
});
// Team Page Script End


// home page switch animation script start
$(function () {
    function swipe() {
        $('.knob')
            .css({
                left: '5px',
                opacity: 1
            })
            .animate({
                left: '55px'
            }, 1200, function () {

                $(this).css({
                    left: '5px',
                    opacity: 0
                });

                setTimeout(() => {
                    $(this).css('opacity', 1);
                    swipe();
                }, 500);
            });
    }
    swipe();
});
// home page switch animation script end

// megamenu start//
jQuery(document).ready(function () {
    jQuery('.mobile-toggle').on('click', function (e) {
        e.stopPropagation();
        var $nav = jQuery('.nav-menu');
        var $toggle = jQuery(this);
        var isOpen = $nav.hasClass('active');
        if (!isOpen) {
            // open
            $nav.addClass('active');
            $toggle.addClass('active');
            jQuery('.mobile-close').addClass('active');
            jQuery('body').addClass('menu-open');

            if (jQuery('.nav-overlay').length === 0) {
                jQuery('body').append('<div class="nav-overlay"></div>');
                jQuery('.nav-overlay').hide().fadeIn(200);
                jQuery('.nav-overlay').on('click', function () {
                    $nav.removeClass('active');
                    $toggle.removeClass('active');
                    jQuery('.mobile-close').removeClass('active');
                    jQuery('body').removeClass('menu-open');
                    jQuery('.nav-overlay').fadeOut(150, function () { jQuery(this).remove(); });
                });
            }
        } else {
            // close
            $nav.removeClass('active');
            $toggle.removeClass('active');
            jQuery('.mobile-close').removeClass('active');
            jQuery('body').removeClass('menu-open');
            jQuery('.nav-overlay').fadeOut(150, function () { jQuery(this).remove(); });
        }
    });
    // Close menu when clicking outside (fallback)
    jQuery(document).on('click', function (e) {
        if (jQuery(e.target).closest('.nav-menu, .mobile-toggle, .mobile-close').length === 0) {
            jQuery('.nav-menu').removeClass('active');
            jQuery('.mobile-toggle').removeClass('active');
            jQuery('.mobile-close').removeClass('active');
            jQuery('body').removeClass('menu-open');
            jQuery('.nav-overlay').fadeOut(150, function () { jQuery(this).remove(); });
        }
    });
    // Mobile close button handler
    jQuery(document).on('click', '.mobile-close', function (e) {
        e.preventDefault();
        jQuery('.nav-menu').removeClass('active');
        jQuery('.mobile-toggle').removeClass('active');
        jQuery('.mobile-close').removeClass('active');
        jQuery('body').removeClass('menu-open');
        jQuery('.nav-overlay').fadeOut(150, function () { jQuery(this).remove(); });
    });
    // Close menu on nav link click (mobile) except when the link is a top-level mega-menu toggle
    jQuery('.nav-menu a').on('click', function (e) {
        if (jQuery(window).width() > 991) return;
        var $link = jQuery(this);
        var $li = $link.closest('li');
        // If this is the top-level anchor inside a .has-mega-menu, do nothing here
        if ($li.hasClass('has-mega-menu') && $li.children('a')[0] === this) {
            // Let the separate handler for '.has-mega-menu > a' manage expanding the mega menu
            return;
        }
        // Otherwise close the off-canvas nav (clicking items inside the mega-menu will close)
        jQuery('.nav-menu').removeClass('active');
        jQuery('.mobile-toggle').removeClass('active');
        jQuery('body').removeClass('menu-open');
        jQuery('.nav-overlay').fadeOut(150, function () { jQuery(this).remove(); });
    });
    function setMegaOpenState(isOpen) {
        jQuery('.header, .nav-menu').toggleClass('mega-open', isOpen);
    }
    jQuery(document).on('mouseenter', '.has-mega-menu', function () {
        if (jQuery(window).width() < 992) return;
        setMegaOpenState(true);
    });
    jQuery(document).on('mouseleave', '.has-mega-menu', function () {
        if (jQuery(window).width() < 992) return;
        setMegaOpenState(false);
    });
    jQuery(document).on('click', '.has-mega-menu > a', function (e) {
        if (jQuery(window).width() >= 992) return;
        e.preventDefault();
        e.stopPropagation();
        var $currentItem = jQuery(this).parent();
        var $currentMega = jQuery(this).siblings('.mega-menu');
        var isOpen = $currentItem.hasClass('active');
        if (isOpen) {
            $currentItem.removeClass('active');
            $currentMega.stop(true, true).slideUp(300);
            setMegaOpenState(false);
            return;
        }
        // Close all other mega submenus
        jQuery('.has-mega-menu').not($currentItem).removeClass('active').children('.mega-menu').stop(true, true).slideUp(300);
        // Open only the clicked item
        $currentItem.addClass('active');
        $currentMega.stop(true, true).slideDown(300);
        setMegaOpenState(true);
    });
});
// megamenu end//

// case study project glance slider script start
jQuery(document).ready(function () {
    jQuery('.casestudy-project-glance-slider').owlCarousel({
    loop: true,
    margin: 0,
    nav: false,
    dots: false,      
    mouseDrag: true,  
    touchDrag: true,  
    freeDrag: false,
    autoplay: true,
    autoplaySpeed: 1000,
    slideTransition: 'linear',  
    responsive: {
        0: {
            items: 1,
            autoplay: true,
        },
    }
    });
});
// case study project glance slider script ended



