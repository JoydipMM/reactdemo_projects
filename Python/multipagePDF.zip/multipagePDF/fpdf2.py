from fpdf import FPDF
from jinja2 import Template, FileSystemLoader, Environment
import datetime
import os
from bs4 import BeautifulSoup  # For parsing HTML

# Load and render the Jinja2 template
env = Environment(loader=FileSystemLoader("."))
template = env.get_template("template.txt")
# with open("pdftemplate.html") as file:
#     template = Template(file.read())

rendered_content = template.render(
    title="Sample PDF Report",
    date=datetime.datetime.now().strftime("%Y-%m-%d"),
    content="This is a sample PDF generated from a Jinja2 template and fpdf2.",
    image_path="/static/plot.png"  # Update with your image path
)

# Parse the rendered HTML to extract the image source
soup = BeautifulSoup(rendered_content, "html.parser")
image_src = soup.find("img")["src"]

# Define a custom PDF class with header and footer
class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Sample PDF Report", 0, 1, "C")

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}", 0, 0, "C")

# Initialize and populate the PDF
pdf = PDF()
pdf.add_page()
pdf.set_font("Arial", "", 12)

# Add rendered content to PDF
for line in rendered_content.splitlines():
    pdf.cell(0, 10, line, ln=True)

# Add the image to the PDF
if os.path.exists(image_src):  # Check if the image file exists
    pdf.image(image_src, x=10, y=30, w=100)  # Adjust the position and size as needed

# Save PDF file
pdf.output("output_report.pdf")

print("PDF generated successfully!")
