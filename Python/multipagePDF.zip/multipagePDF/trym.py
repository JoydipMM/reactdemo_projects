from weasyprint import HTML
from fpdf import FPDF
from jinja2 import Environment, FileSystemLoader
from bs4 import BeautifulSoup
import os

# Function to convert pixels to mm
def pixels_to_mm(px):
    return (px / 96) * 25.4  # Assuming 96 DPI

# Create a PDF class
class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Dynamic Multi-Page PDF Report", 0, 1, "C")

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}", 0, 0, "C")

# Initialize PDF
pdf = PDF()

# Set the custom page size (1920 x 1080 pixels converted to mm)
pdf.add_page(orientation='P', format=(pixels_to_mm(1920), pixels_to_mm(1080)))
pdf.set_font("Arial", "", 12)
pdf.set_margins(10, 0, 0)  # Set margins to zero for full use of the page

# Set up Jinja2 environment
env = Environment(loader=FileSystemLoader("."))

# Prepare image path
image_path = "static/plot.png"  # Update with your image path

# Dynamic data for each page
dynamic_data = [
    {"title": "Welcome to Page 1", "content": "This is the content of the first page."},
    {"title": "Welcome to Page 2", "content": "This is the content of the second page."},
    {"title": "Welcome to Page 3", "content": "This is the content of the third page."},
]

# Templates list
templates = ["templates/template.html", "templates/template2.html", "templates/template3.html"]

for i, template_name in enumerate(templates):
    # Load and render the template with dynamic content
    template = env.get_template(template_name)
    rendered_html = template.render(title=dynamic_data[i]['title'], content=dynamic_data[i]['content'], image_path=image_path)

    # Parse the rendered HTML
    soup = BeautifulSoup(rendered_html, "html.parser")

    # Extract and add title
    pdf.set_font("Arial", "B", 16)  # Bold for the title
    pdf.cell(0, 10, soup.h1.text, ln=True)
    pdf.set_font("Arial", "", 12)  # Reset font for normal text

    # Extract and add content
    pdf.multi_cell(0, 10, soup.find_all('p')[0].text)  # The content is in the first <p> tag

    # Add the image to the PDF
    image_src = soup.find("img")["src"]  # Extract the image source

    # Check if the image file exists
    if os.path.exists(image_src):  
        pdf.image(image_src, x=10, y=pdf.get_y() + 10, w=100)  # Adjust position and size as needed
    else:
        print(f"Image not found at path: {image_src}")  # Debugging: image does not exist

    # Add a new page for the next template
    if i < len(templates) - 1:  # Avoid adding a new page after the last template
        pdf.add_page(orientation='P', format=(pixels_to_mm(1920), pixels_to_mm(1080)))
        pdf.set_font("Arial", "", 12)  # Reset font for the new page

# Save the PDF
output_path = "dynamic_multi_page_output_new.pdf"
pdf.output(output_path)
print(f"PDF generated successfully at {output_path}!")

