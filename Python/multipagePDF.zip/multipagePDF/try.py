from fpdf import FPDF
from jinja2 import Environment, FileSystemLoader
from bs4 import BeautifulSoup
import os

# Set up the Jinja2 environment
env = Environment(loader=FileSystemLoader("."))
template = env.get_template("template.html")

# Render the template with the required data
rendered_html = template.render(
    title="Sample PDF Report",
    date="2024-01-01",
    content="This is a sample PDF generated from an HTML template.",
    image_path="static/plot.png"  # Update with your image path
)

# Parse the rendered HTML
soup = BeautifulSoup(rendered_html, "html.parser")

# Create a PDF class
class PDF(FPDF):

    # def __init__(self, orientation='L', unit='mm', format='A4'):
    #     # Set the page size here. You can specify custom dimensions.
    #     # For example, for a custom size of 210mm x 297mm (A4)
    #     self.page_width = 677.33
    #     self.page_height = 381
    #     super().__init__(orientation, unit, format)

    # def __init__(self):
    #     super().__init__(orientation='L', unit='mm', format='A4')  # Call the parent constructor
    #     self.set_page_size(1920, 1080)  # Set custom page size in mm

    def __init__(self):
        super().__init__()

    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Sample PDF Report", 0, 1, "C")

    def footer(self):
        self.set_y(-20)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}", 0, 0, "C")

    def set_page_size(self, width, height):
        # Convert pixels to mm
        mm_width = (width / 72) * 25.4
        mm_height = (height / 72) * 25.4
        self.add_page()  # Add a new page
        self.set_margins(20, 0, 0)  # Optional: set margins to 0

        # Set the page size using the calculated width and height
        self.w = mm_width
        self.h = mm_height


        # Function to convert pixels to mm
def pixels_to_mm(px):
    return (px / 96) * 25.4  # Assuming 96 DPI

# Initialize PDF
pdf = PDF()
# pdf.add_page()
pdf.add_page(orientation='P', format=(pixels_to_mm(1920), pixels_to_mm(1080)))  # Custom size in mm
pdf.set_font("Arial", "", 12)

# Extract and add title
pdf.set_font("Arial", "B", 16)  # Bold for the title
pdf.cell(0, 10, soup.h1.text, ln=True)
pdf.set_font("Arial", "", 12)  # Reset font for normal text

# Extract and add date
pdf.cell(0, 10, soup.p.text, ln=True)

# Extract and add content
pdf.multi_cell(0, 10, soup.find_all('p')[1].text)  # The content is in the second <p> tag

# Add the image to the PDF
# image_src = soup.find("img")["src"]  # Extract the image source
# if os.path.exists(image_src):  # Check if the image file exists
#     pdf.image(image_src, x=10, y=pdf.get_y() + 10, w=100)  # Adjust position and size as needed

    # Add the image to the PDF
image_src = soup.find("img")["src"]  # Extract the image source
print(f"Image source: {image_src}")  # Debugging: print image path

# Check if the image file exists
if os.path.exists(image_src):  
    print("Image found, adding to PDF.")  # Debugging: image exists
    pdf.image(image_src, x=10, y=pdf.get_y() + 10, w=100)  # Adjust position and size as needed
else:
    print(f"Image not found at path: {image_src}")  # Debugging: image does not exist

# Save the PDF
pdf.output("output_with_image_from_html.pdf")

print("PDF generated successfully with formatted content from HTML!")
