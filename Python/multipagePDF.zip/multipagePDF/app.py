from weasyprint import HTML
# from pdf2image import convert_from_path
from fpdf import FPDF

# Step 1: Generate PDF from HTML content with WeasyPrint
html_content = """
<html>
<head>
    <style>
        h1 { color: blue; font-family: Arial; }
        p { font-size: 12pt; color: black; background:red; }
        .box{ width: 200px; height: 200px; background: linear-gradient(to bottom,  #1e5799 0%,#2989d8 50%,#207cca 51%,#7db9e8 100%); display: inline-block; margin:0px 20px; }
        .wrap{ width:100%; display:inline-flex; margin:0px -20px; }
    </style>
</head>
<body>
    <h1>Styled Header with CSSvvbvbvbvvb</h1>
    <p>This paragraph is styled with CSS in WeasyPrint and will be included in fpdf2.</p>
    <div class="wrap">
        <div class="box"></div>
        <div class="box"></div> <div class="box"></div>
    </div>
    <div class="wrap">
        <div class="box"></div>
        <div class="box"></div> <div class="box"></div>
    </div>
</body>
</html>
"""



# Step 2: Convert the PDF page(s) to an image using pdf2image
# images = convert_from_path(html_pdf_path, dpi=300)
# image_path = "temp_image.png"
# images[0].save(image_path, "PNG")  # Save the first page as PNG

# Step 3: Add the PNG image to an fpdf2 PDF
pdf = FPDF()
pdf.add_page()
# pdf.image(image_path, x=10, y=10, w=190)  # Position the image

# Add additional content with fpdf2 if needed
# pdf.set_font("Arial", "B", 12)
# pdf.set_text_color(0, 0, 0)
# pdf.cell(0, 10, "This is additional content added with fpdf2", ln=True)

# Save final PDF
# pdf.output("final_output_with_css.pdf")
# print("PDF created successfully with CSS-styled content.")


# Save WeasyPrint-generated PDF
html_pdf_path = "temp_content.pdf"
HTML(string=html_content).write_pdf(html_pdf_path)
