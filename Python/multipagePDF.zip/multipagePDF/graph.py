import matplotlib.pyplot as plt
from flask import Flask, make_response, render_template

from weasyprint import HTML
import datetime

app = Flask(__name__)

@app.route('/pdf')
def graph():
    # Generate the plot
    plt.plot([1, 2, 3, 4], [1, 4, 9, 16])
    plt.xlabel('x-axis')
    plt.ylabel('y-axis')
    plt.title('Sample Plot')

    # Save the plot as a PNG file in the static folder
    plot_filename = "plot.png"
    plt.savefig(f"static/{plot_filename}")
    plt.close()


    # Render HTML from Jinja2 template
    html = render_template('graph.html', title="Sample PDF Report", date=datetime.datetime.now().date())

    # Convert the HTML to a PDF using WeasyPrint
    pdf = HTML(string=html).write_pdf()

    # Create a response object with the PDF file
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'inline; filename=report.pdf'

    return response

    # Render the template with the image filename
    return render_template('graph.html', plot_filename=plot_filename)



if __name__ == '__main__':
    app.run(debug=True)
