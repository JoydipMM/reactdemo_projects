from flask import Flask, render_template
import plotly.graph_objects as go
import numpy as np
import json
from plotly.utils import PlotlyJSONEncoder

# create a Flask instance
app = Flask(__name__) 

# create a route
@app.route('/')

# def index():
#    return "Hello world"

def index():
    fruitlist = ["apple", "mango", "orange"]
    name = "Joy"


    # Create a basic pie chart
    labels = ['App', 'Bananas', 'Grapes', 'Oranges']
    values = [4500, 2500, 1050, 1500]


    # Data for grouped bar chart
    vendors = ['Vendor A', 'Vendor B', 'Vendor C']
    fruits = ['Apples', 'Bananas', 'Grapes']
    
    # Sales data for each vendor and fruit
    sales_data = {
        'Vendor A': [4500, 2500, 1050],
        'Vendor B': [3000, 4000, 1500],
        'Vendor C': [2000, 3000, 3500]
    }

    # Create a styled pie chart
    fig = go.Figure(
        data=[go.Pie(
            labels=labels,
            values=values,
            marker=dict(colors=['#ff0000', '#66b3ff', '#99ff99', '#ffcc99'], line=dict(color='#ffffff', width=2)),  # Custom colors and Outline color and width
            textinfo='label+percent',  # Show label and percentage
            insidetextorientation='radial',  # Inside text radial alignment
            pull=[0, 0, 0, 0], # Pull out the first slice
            hole=0.4,  # Make it a donut chart
        )]
    )

    fig2 = go.Figure(
        data=[go.Pie(
            labels=labels,
            values=values,
            marker=dict(colors=['#ff00ff', '#66b2ff', '#99ff99', '#ffcc99']),  # Custom colors
            textinfo='label+percent',  # Show label and percentage
            #insidetextorientation='radial',  # Inside text radial alignment
            pull=[0, 0, 0, 0], # Pull out the first slice
            hole=0.4,  # Make it a donut chart
        )]
    )

    # Create a grouped bar chart
    fig3 = go.Figure()

    # Add bars for each vendor
    for vendor in vendors:
        fig3.add_trace(go.Bar(
            x=fruits,
            y=sales_data[vendor],
            name=vendor
        ))

    # Create figure
    fig4 = go.Figure()  

    # Add traces, one for each slider step
    for step in np.arange(0, 5, 0.1):
        fig4.add_trace(
            go.Scatter(
                visible=False,
                line=dict(color="#00CED1", width=6),
                name="𝜈 = " + str(step),
                x=np.arange(0, 10, 0.01),
                y=np.sin(step * np.arange(0, 10, 0.01))))

    # Make 10th trace visible
    fig4.data[10].visible = True

    # Create and add slider
    steps = []
    for i in range(len(fig4.data)):
        step = dict(
            method="update",
            args=[{"visible": [False] * len(fig4.data)},
                {"title": "Slider switched to step: " + str(i)}],  # layout attribute
        )
        step["args"][0]["visible"][i] = True  # Toggle i'th trace to "visible"
        steps.append(step)

    sliders = [dict(
        active=10,
        currentvalue={"prefix": "Frequency: "},
        pad={"t": 50, "b": 20},
        font={
            'size': 12,
            'color': 'black'
        },
        len= 1,  # Length of the slider (0 to 1)
        y= 0.05,  # Position along the y-axis
        steps=steps,
        bgcolor= 'lightgray',  # Background color of the slider
        
            
    )]


    # Add layout options (title, background color)
    fig.update_layout(
        title_text='Fruit Sales Distribution',
        title_font=dict(size=24, color='#000000', weight="bold", family="Playfair Display"),
        annotations=[dict(text='Fruits', x=0.5, y=0.5, font_size=20, font_color="#ff0000", showarrow=False)],  # Add text in center of donut chart
        paper_bgcolor='rgba(225,225,225,1)',  # Transparent background
        plot_bgcolor='rgba(225,225,225,1)' ,   # Transparent plot area background
        margin=dict(l=0, r=0, t=40, b=10),  # Margins around the chart
        legend=dict(
            title='', # legend title
            x=0.2,  # Horizontal position (1 means far right)
            y=-0.1,  # Vertical position (1 means top)
            xanchor='left',  # Anchor point for x
            yanchor='bottom',    # Anchor point for y
            orientation='h',  # Orientation of the legend
        ),
    )

    fig2.update_layout(
        title_text='Sales Distribution',
        title_font=dict(size=24, color='#ffffff', weight="bold", family="Playfair Display"),
        annotations=[dict(text='Fruits', x=0.5, y=0.5, font_size=20, font_color="#ffffff", showarrow=False)],  # Add text in center of donut chart
        paper_bgcolor='rgba(13,73,124,1)',  # Transparent background
        plot_bgcolor='rgba(13,73,124,1)',    # Transparent plot area background
        legend=dict(
            title='', # legend title
            x=0.1,  # Horizontal position (1 means far right)
            y=-0.4,  # Vertical position (1 means top)
            xanchor='left',  # Anchor point for x
            yanchor='bottom',    # Anchor point for y
            orientation='h',  # Orientation of the legend
            bgcolor="darkblue",
            font=dict(color='#ffffff'),
            itemsizing='constant',  # Keep legend item sizes consistent
        ),
    )   

    # Customize layout
    fig3.update_layout(
        barmode='group',
        title='Fruit Sales by Vendor',
        xaxis_title='Fruits',
        yaxis_title='Sales',
        legend_title='Vendors',
        template='plotly_white',  # Use a white background for the chart
        font=dict(size=14),  # Font size for all text in the chart
    )

    fig4.update_layout(
        sliders=sliders,
        margin=dict(l=0, r=0, t=0, b=30)
    )


    # Convert the Plotly figure to JSON format using PlotlyJSONEncoder
    graph_json = json.dumps(fig, cls=PlotlyJSONEncoder)
    graph_json2 = json.dumps(fig2, cls=PlotlyJSONEncoder)
    graph_json3 = json.dumps(fig3, cls=PlotlyJSONEncoder)
    graph_json4 = json.dumps(fig4, cls=PlotlyJSONEncoder)

    # Pass the graph JSON to the template

    return render_template("index.html", fruitlist=fruitlist, name=name, graphJSON=graph_json, graphJSON2=graph_json2, graphJSON3=graph_json3, graphJSON4=graph_json4)

# @app.route('/about/<name>')
@app.route('/about')

def about():
#    return "User Hello world {}".format(name)
    key = ['January', 'February', 'March', 'April', 'May', 'June', 'July']
    values = [65, 59, 80, 81, 56, 55, 40]

    chart_data = {
        'categories': ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        'series': [
            {'name': 'Series 1', 'data': [10, 20, 15, 25, 30]},
            {'name': 'Series 2', 'data': [15, 10, 20, 30, 25]},
            {'name': 'Series 3', 'data': [20, 25, 30, 15, 10]}
        ]
    }
    return render_template("about.html", key=key, values=values, chart_data=chart_data)

@app.route('/contact')   
def contact():
#    return "User Hello world {}".format(name)
    labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July']
    data = [65, 59, 80, 81, 56, 55, 40]
    return render_template("contact.html", labels=labels, data=data)


if __name__ == '__main__':
    app.run(debug=True)